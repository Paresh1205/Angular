import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dept-list',
  templateUrl: './dept-list.component.html',
  styleUrls: ['./dept-list.component.css']
})
export class DeptListComponent implements OnInit {

  Departments: any;

  constructor() { }

  ngOnInit() {
    this.Departments = [
      { "id": 1, "name": "HTML5" },
      { "id": 2, "name": "CSS3" },
      { "id": 3, "name": "Bootstrap" },
      { "id": 4, "name": "Javascript" },
      { "id": 5, "name": "Angular" }
    ]
  }

}
