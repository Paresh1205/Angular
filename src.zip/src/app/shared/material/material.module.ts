import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatAutocomplete, MatFormField } from '@angular/material';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MatAutocomplete,
    MatFormField
  ],
  exports: [
    MatAutocomplete,
    MatFormField
  ]
})
export class MaterialModule { }
